# Changelog

## 1.0.0 - 2026-11-14 (Elyrine Baileys)

- feat: fork `@itsliaaa/baileys` 0.5.6 as `elyrine-baileys`.
- feat: new link preview engine with adaptive thumbnails that keep the source aspect ratio; HQ previews upload the original resolution (now default).
- feat: `sock.sendLinkPreview()` for chats, groups, status and channels.
- feat: SSRF guard for every link preview request and redirect hop; optional `link-preview-js` support.
- feat: merge from Elaina Baileys: MessageBuilder (`MB`), VoIP, Postgres/MySQL/Mongo/Redis/NekoDB auth, TTL cache, modern messages, newsletter status, voice recognition, native-flow helpers, optional AnchorGuard.
- feat: merge from Axleys: `newsletterCanPostStatus()`, `albumParentKey`.
- chore: rename identity (package, repository, constants, sticker pack defaults); credits preserved.

## 0.5.6 - 2026-11-14

- fix: don't build downloads on the `a.whatsapp.net` placeholder host.
- fix: encrypt a retry resend once, also for groups.
- chore: update WAProto and socket version to `2.3000.1054623785`.

## 0.5.5 - 2026-11-13

- chore: update WAProto and socket version to `2.3000.1054357583`.

## 0.5.4 - 2026-11-12

- chore: update WAProto and socket version to `2.3000.1054241206`.

## 0.5.3 - 2026-11-11

- fix: treat offline zero node as online.
- fix: include the WebSocket close code and reason in the connection closed error.
- fix: do not announce presence on a partial `creds.update`.
- chore: update WAProto and socket version to `2.3000.1053984976`.

## 0.5.2 - 2026-11-10

- fix: add the missing `payment_key_info` stanza attributes when sending `buttons` with `interactiveMessage`.
- fix: only record `sender-key-memory` for devices that received an SKDM.
- fix: do not send retry receipts for undecryptable `fromMe` messages.
- fix: add view once meta tag when sending view once messages.
- chore: update WAProto to `2.3000.1053755068`.
- chore: update default socket version to `2.3000.1053853618`.

## 0.5.1 - 2026-11-06

- fix: fix a typo in `prepareWAMessageMedia()` affecting MIME type detection.

## 0.5.0 - 2026-11-06

- feat: add the missing `genai_sticker` media type when sending `stickerMessage` with the `isAiSticker` attribute.
- feat: automatically detect the MIME type when `mimetype` is empty in the media payload.
- feat: include additional metadata when sending media to newsletters.
- chore: reduce the use of protobuf `.create()` and `.fromObject()` methods when sending messages.
- fix: sticker pack metadata could not be accessed when sending sticker pack messages to newsletter, preventing stickers from being downloaded.
- chore: update WAProto to `2.3000.1053278567`.
- chore: update default socket version to `2.3000.1053373443`.

## 0.4.4 - 2026-11-04

- fix: correctly detect the exact media type in `prepareWAMessageMedia()`.
- chore: update WAProto to `2.3000.1052812464`.
- chore: update default socket version to `2.3000.1052983891`.

## 0.4.3 - 2026-11-01

- chore: update WAProto and socket version to `2.3000.1052238679`.
- fix: prevent `form_message` send failures.
- fix: prevent errors when marking messages as successful in `messageRetryManager`.
- chore: add the missing `server_transcode` parameter to newsletter media uploads.
- chore: expand media upload path and HKDF key mappings.
- chore: add `isBoom` for `HttpError`.
- feat: add debounced phash mismatch recovery on bad ACK.

## 0.4.2 - 2026-10-27

- refactor: Refactor `useMultiFileAuthState()`, `useSingleFileAuthState()`, and `useSqliteAuthState()`.
- chore: Add the `form_message` node attribute when sending A2UI forms via `interactiveMessage`.

## 0.4.1 - 2026-10-26

- refactor: reduce transitive dependencies from 13 to just 2.
- refactor: migrate signal transport to a Rust-based WASM implementation.
- refactor: make `ws` optional for Node.js 22 and above. For older Node.js versions, `ws` must be installed manually.
- chore: reintroduce `printQRInTerminal` in `makeWASocket()`.
- fix: resolve `peerDependencies` conflicts.
- fix: ACK `<status>` stanzas.
- fix: release the per-socket `AsyncLocalStorage` on socket end.
- fix: pairing code broken by missing notification stage check and wrong nonce value.
- fix: avoid QR regression in `validateConnection` check.
- ... I forgot the rest.